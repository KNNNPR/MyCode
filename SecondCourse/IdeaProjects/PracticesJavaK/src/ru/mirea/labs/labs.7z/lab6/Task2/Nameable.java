package ru.mirea.labs.lab6.Task2;

interface Nameable {
    String getName();
}
