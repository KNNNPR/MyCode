package ru.mirea.labs.lab12.TaskTwo;

public class eetyn {
}
