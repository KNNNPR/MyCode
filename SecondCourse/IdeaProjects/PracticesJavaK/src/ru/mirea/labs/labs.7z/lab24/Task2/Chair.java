package ru.mirea.labs.lab24.Task2;

// Интерфейс для стула
interface Chair {
    void sit();
}
