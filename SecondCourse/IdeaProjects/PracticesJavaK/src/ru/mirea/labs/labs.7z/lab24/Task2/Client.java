package ru.mirea.labs.lab24.Task2;

// Клиент, использующий интерфейс стул
class Client {
    public void sit(Chair chair) {
        chair.sit();
    }
}