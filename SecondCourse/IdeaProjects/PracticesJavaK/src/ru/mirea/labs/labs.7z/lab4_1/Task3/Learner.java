package ru.mirea.labs.lab4_1.Task3;

public class Learner {
    protected String name;

    @Override
    public String toString() {
        return("Learnre " + this.name);
    }
}
