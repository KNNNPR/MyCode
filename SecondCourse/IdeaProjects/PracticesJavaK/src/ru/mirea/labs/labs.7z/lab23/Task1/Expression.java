package ru.mirea.labs.lab23.Task1;

public abstract class Expression {
    public abstract double evaluate(double x);
}
