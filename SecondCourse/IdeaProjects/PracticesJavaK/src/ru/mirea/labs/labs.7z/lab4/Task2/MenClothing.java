package ru.mirea.labs.lab4.Task2;

public interface MenClothing {
    void dressMan();
}
