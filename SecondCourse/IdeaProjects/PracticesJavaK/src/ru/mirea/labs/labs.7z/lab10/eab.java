package ru.mirea.labs.lab10;

public class eab {
}
