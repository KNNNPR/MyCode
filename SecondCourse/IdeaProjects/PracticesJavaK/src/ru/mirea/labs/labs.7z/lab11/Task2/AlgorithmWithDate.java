package ru.mirea.labs.lab11.Task2;

public class AlgorithmWithDate {
}
