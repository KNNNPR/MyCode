package ru.mirea.labs.lab6.Task2;

public class Test {
    public static void main(String[] args) {
        Dog userDog = new Dog("pitbull");
        Planet userPlanet = new Planet("ISO-776-bn");
        System.out.println(userDog.getName());
        System.out.println(userPlanet.getName());
    }
}
