package ru.mirea.labs.lab7;

interface Movable {
    void moveUp();
    void moveDown();
    void moveRigth();
    void moveLeft();
}
