package ru.mirea.labs.lab4_1.Task1;

public class Shape {
    protected String type;
    public String getType() {
        return(type);
    }
    public double getArea() {
        return(0.0);
    }
    public double getPerimeter() {
        return(0.0);
    }

    public String toString() {
        return ("Shape");
    }
}
