package ru.mirea.labs.lab17.UMLDiagram;

public class StudentView {
    public void printStudentDetails(String outRollNo, String outName) {
        System.out.println("Student");
        System.out.println("Name: " + outName);
        System.out.println("RollNo: " + outRollNo);
    }
}
