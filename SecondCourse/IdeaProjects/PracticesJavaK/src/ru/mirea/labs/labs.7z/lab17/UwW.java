package ru.mirea.labs.lab17;

public class UwW {
    
}
