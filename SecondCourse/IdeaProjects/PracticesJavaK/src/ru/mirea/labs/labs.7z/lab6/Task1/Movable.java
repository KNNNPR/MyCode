package ru.mirea.labs.lab6.Task1;

interface Movable {
    void moveUp();
    void moveDown();
    void moveRigth();
    void moveLeft();
}
