package ru.mirea.labs.lab18;

public class Task2 {
}
